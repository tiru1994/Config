This folder should contain following files   
1. Mac New Script.sh

Delete any other files if Present.

Instructions to Run the Script

1) Login as administrator

2) Run the Mac New Script.sh file.

3) Output.txt will be generated. Copy this file and Return the 'Output' File to the Auditor. 

4) Delete the "Mac New Script.sh" file and the output file from the system.