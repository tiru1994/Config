
select Alt.name, Alt.filename, alt.dbid, DB.name as DBName from sys.sysaltfiles Alt inner join sys.sysdatabases DB ON Alt.dbid = DB.dbid
go