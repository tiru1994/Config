Created Date - 16/12/2019
Script Version - 2
+++++++++++++++++++++++Script Execution On MySQL Windows Platform++++++++++++++++++++++++

======2.1. Auditing & Logging ==============
MySQL_2.1.1. Enable logging in MySQL
show variables like '%log%';

MySQL_2.1.2 Make sure the audit plugin can be unloaded
SELECT LOAD_OPTION FROM information_schema.plugins WHERE PLUGIN_NAME='audit_log';

=====2.2. Password Management=========

MySQL_2.2.1. Protect root account of MySQL with strong password
---Manual check----

MySQL_2.2.2  Ensure Passwords Are Set for All MySQL Accounts
SET PASSWORD FOR <user>@'<host>' = PASSWORD('<clear password>')
/*NOTE: Replace <user>, <host>, and <clear password> with appropriate values.*/

MySQL_2.2.3 Ensure Password Policy Is in Place 
SHOW VARIABLES LIKE 'validate_password%';
Check	if	users	have	a	password	which	is	identical	to	the	username
SELECT User,Password,Host FROM mysql.user WHERE password=CONCAT('*', UPPER(SHA1(UNHEX(SHA1(user)))));

======2.3. System Configuration=======
MySQL_2.3.1. Start up MySQL with the parameter to disable the use of symlinks
SHOW VARIABLES LIKE 'have_symlink';

MySQL_2.3.2. Remove sample preinstalled databases
SELECT name FROM sys.databases WHERE name LIKE 'AdventureWorks%' OR name = 'pubs' OR name = 'Northwind';

MySQL_2.3.3. Disable TCP networking from MySQL
show variables like 'skip_networking';

MySQL_2.3.4. MySQL should be run on a non default port
SHOW GLOBAL VARIABLES LIKE 'PORT';

MySQL_2.3.5 Ensure Replication Traffic Is Secured 
---Manual Check---

MySQL_2.3.6  Ensure 'sql_mode' Contains 'STRICT_ALL_TABLES' 
SHOW VARIABLES LIKE 'sql_mode'; 

=======2.4. User Rights and Security Options=======

2.4.1. Run MySQL under other user id and gid
---Manual check----

2.4.2. Prevent anonymous access to MySQL
SELECT user from mysql.user where user = '';

2.4.3. Sensitive privileges granted to unnecessary users
SELECT user, host from mysql.user where (Select_priv = 'Y') or (Insert_priv = 'Y') or (Update_priv = 'Y') or (Delete_priv = 'Y') or (Create_priv = 'Y') or (Drop_priv = 'Y');
SELECT user, host from mysql.db where db = 'mysql' and ( (Select_priv = 'Y') or (Insert_priv = 'Y') or (Update_priv = 'Y') or (Delete_priv = 'Y') or (Create_priv = 'Y') or (Drop_priv = 'Y'));


2.4.4. Disable unauthorized reading from local files
show variables like 'local_infile';

2.4.5. Rename the administrator account
SELECT name, is_disabled FROM sys.server_principals WHERE name = sa;

2.4.6. Review list of privileges granted to user
show variables like 'skip_grant_tables';

2.4.7. Restrict connections for a single user
show status like '%onn%';

+++++++++++++Script End+++++++++++++++++++++++++++