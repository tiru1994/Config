A DBA from the client needs to execute these scripts using a user ID with the DBA_ROLE allocated.

i) Database script: (Deloitte_Oracle_11g_DB_v11.sql)

Only one script exists for both Windows and Unix/Linux operating systems. The script will write information to many text files, which may become quite large, so please request the database administrator (DBA) to zip them and share with Deloitte Team.

ii) Operating system script:

For Windows: Deloitte_Oracle_11g_WIN_v11_01.bat
For Unix: Deloitte_Oracle_11g_Unix_v11.sh

The script was developed for an Oracle 10g environment in order to obtain information, not contained in the database itself. Versions are available for Windows and Unix/Linux operating systems. The Unix/Linux script will create a tarball, called oracle_home_dbs.tar, while the Windows script will create several text files, called WIN<item>.txt. Please share oracle_home_dbs.tar OR WIN<item>.txt files with the Deloitte Team.